import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const Startup = () => {
    return (
        <View>
            <Text></Text>
        </View>
    )
}

export default Startup

const styles = StyleSheet.create({})
