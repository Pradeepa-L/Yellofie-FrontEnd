import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const Root = () => {
    return (
        <View>
            <Text>Yellofie</Text>
        </View>
    )
}

export default Root

const styles = StyleSheet.create({})
